<!DOCTYPE>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Drycleaning</title>
<style type="text/css">
@import url("css/style.css");
</style>
</head>

<body>
<div id="wrapper_thanks">

<div id="landingpage">
<div class="logo"><img class="thanks" src="images/moxian_thanks-logo.png" width="217" height="81" alt=""></div>	
<div class="thanku">
<div class="thank">
THANK YOU
</div>
</div>

	



	
    
    
    

</div>
</div>
</body>
</html>